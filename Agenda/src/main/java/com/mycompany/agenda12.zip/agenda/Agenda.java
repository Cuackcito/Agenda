/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.agenda;

/**
 *
 * @author Cuack
 */
public class Agenda {

    public static void main(String[] args) {
        System.out.println("Hello World!");
         System.out.println("Hello sosa!");
          System.out.println("Hello Kat!");

    }
}
